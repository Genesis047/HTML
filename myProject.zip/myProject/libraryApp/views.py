# Create your views here.
#Django Admin Username: Ryan  //  Password: ryan3000
from django.shortcuts import render, redirect
from .models import booksDB, stud_request

from .models import issue as issueDB

from libraryApp.forms import bookForm, studentForm, issueForm
from django.contrib import messages
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout

def home(request):
    return render(request, '1Home.html')


def books(request):
    data = booksDB.objects.all()
    bookdetail_ = {"book_details": data}
    return render(request, "6Books.html", bookdetail_)


@login_required(login_url='/')
def manage(request):
    data = booksDB.objects.all()
    bookdetail_ = {"book_details": data}
    return render(request, "3Managementbooks.html", bookdetail_)


@login_required(login_url='/')
def issue(request):
    return render(request, '4BookIssue.html')


@login_required(login_url='/')
def returns(request):
    data = issueDB.objects.all()
    fine_ = {"fines": data}
    return render(request, '4BookReturn.html', fine_)


@login_required(login_url='/')
def requests(request):
    data = stud_request.objects.exclude(status='Aprv.')
    studentdetail_ = {"student_details": data}
    return render(request, '5Studentrequest.html', studentdetail_)


#add book
@login_required(login_url='/')
def add_book(request):  
    if request.method == "POST":  
        form = bookForm(request.POST)
        if form.is_valid():  
            try:  
                form.save()
                messages.success(request, "Book added successfully!" )  
                return redirect('/manage')
                print('saved')  
            except:  
                pass  
    else:  
        form = bookForm()
    return render(request,'addbook.html',{'form':form})  


@login_required(login_url='/')
def delete(request, person_pk):
    try:
        query = booksDB.objects.get(pk=person_pk)
        query.delete()
        messages.success(request, "Book deleted successfully" )  
        return redirect('/manage')

    except:
        messages.error(request, "Something went wrong!" )


#submit request form
def add_request(request, person_id):
    book_info = get_object_or_404(booksDB, pk=person_id)

    student_Form= studentForm(request.POST or None)
    if student_Form.is_valid():
        new_book = student_Form.save(commit=False) # Don't save it yet
        new_book.book_info = book_info
        new_book.save() # Now save it
        return redirect('/books')

    return render(request, 'addrequest.html', {'form': student_Form})


@login_required(login_url='/')
def reject(request, rejection):
    try:
        query = stud_request.objects.get(pk=rejection)
        query.delete()
        messages.success(request, "Student rejected successfully :(" )
        return redirect('/requests')

    except:
        messages.error(request, "Something went wrong" )       



@login_required(login_url='/')
def issue_book(request, person_id):
    student_info = get_object_or_404(stud_request, pk=person_id)

    student_Form= issueForm(request.POST or None)
    if student_Form.is_valid():

        issue = stud_request.objects.get(pk=person_id)
        issue.status = request.POST['status']
        issue.save()
        
        new_book = student_Form.save(commit=False) # Don't save it yet
        new_book.student_info= student_info# Add person
        new_book.save() # Now save it

        messages.success(request, "Student approved successfully" )

        return redirect('/requests')

    return render(request, 'issuebook.html', {'form': student_Form})



def editing(request, id):
    issue = issueDB.objects.get(id=id)
    return render(request, 'edit.html', {'issue':issue})


def updating(request, id):
    issue = issueDB.objects.get(pk=id)
    issue.status = request.POST['status']
    issue.save()
    return redirect('/return')

