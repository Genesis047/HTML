$(document).ready(function(){
    $('#contact-form').on('submit', function(event){
        event.preventDefault();

        $.ajax({
            url: '/contact/',
            type: 'POST',
            // headers: {'X-CSRFToken': '{{ csrf_token }}'},
            data: $('#contact-form').serialize(),
            
            beforeSend: function () {
                $("#contactModal").modal("show");
            },
            
            success: function(data) {
                $('#contactModal .modal-body').html(data);
            }
        });
    });
});