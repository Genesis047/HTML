$(document).ready(function(){
  $('body').scrollspy({target: ".navbar", offset:10}); 
   
  $('#myModal').on('hidden.bs.modal', function () {
    $(this).find('form').trigger('reset');
  }) 
});

