from django.db import models
from django.db.models import Model

# Create your models here.
#py manage.py makemigrations
#py manage.py migrate

class booksDB(Model):
	book_id = models.AutoField(primary_key=True, blank=True, null=False)
	book_image = models.ImageField(blank=True, null=True, upload_to="images/")
	title = models.CharField(max_length=200, blank=True, null=True)
	author = models.CharField(max_length=200, blank=True, null=True)
	publish_date = models.DateTimeField(blank=True, null=True)
	isbn = models.IntegerField(blank=True, null=True)

	class Meta:
		db_table = 'books'

		
class stud_request(Model):
	tupc_id = models.IntegerField(primary_key=True, blank=True, null=False)
	first_name = models.CharField(max_length=200, blank=True, null=True)
	last_name = models.CharField(max_length=200, blank=True, null=True)
	email = models.EmailField(max_length=200, blank=True, null=True)
	date_requested = models.DateTimeField(auto_now_add=True, blank=True, null=True )
	book_info = models.ForeignKey(booksDB, on_delete=models.CASCADE, blank=True, null=True)
	status = models.CharField(max_length=200, default='Pending')
	
	class Meta:
		db_table = 'student_request'


class issue(Model):
	student_info = models.ForeignKey(stud_request, on_delete=models.CASCADE, blank=True, null=True)
	issue_date = models.DateTimeField(blank=True, null=True)
	expiration_date = models.DateTimeField(blank=True, null=True)
	status = models.CharField(max_length=200, blank=True, null=True, default='Borrowing')

	class Meta:
		db_table = 'issue_book'
