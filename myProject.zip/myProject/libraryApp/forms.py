from django import forms 
from libraryApp.models import booksDB, stud_request, issue


class bookForm(forms.ModelForm):  
    class Meta:  
        model = booksDB 
        fields = ('book_image', 'title', 'author', 'publish_date', 'isbn')

        widgets = {
            'image': forms.ClearableFileInput(),
            'title': forms.TextInput(attrs=
                {'placeholder': 'Title', 'class':'form-control', 'required': 'required'}),
            'author': forms.TextInput(attrs=
                {'placeholder': 'Author', 'class':'form-control', 'required': 'required'}),
            'publish_date': forms.DateInput(attrs={
                'placeholder': 'MM-DD-Year', 'class':'form-control', 'required': 'required'}),
            'isbn': forms.NumberInput(attrs={
                'placeholder': 'ISBN', 'class':'form-control', 'required': 'required'}),
            
        }


class studentForm(forms.ModelForm):  
    class Meta:  
        model = stud_request 
        #exclude = ('book_info',)
        fields = ('first_name', 'last_name', 'tupc_id', 'email')
        readonly_fields = ['date_requested']

        widgets = {
            'first_name': forms.TextInput(attrs=
                {'placeholder': 'First Name', 'class':'form-control', 'required': 'required'}),
            'last_name': forms.TextInput(attrs=
                {'placeholder': 'Last Name', 'class':'form-control', 'required': 'required'}),
            'tupc_id': forms.TextInput(attrs=
                {'placeholder': 'TUPC-XX-XXXX', 'class':'form-control', 'required': 'required',}),           
            'email': forms.EmailInput(attrs={
                'placeholder': 'Email Address', 'class':'form-control', 'required': 'required'}),
            
        }


class issueForm(forms.ModelForm):
    class Meta:
        model = issue
        fields = ('issue_date', 'expiration_date', )

        widgets = {
            'issue_date': forms.DateInput(attrs={
                'placeholder': 'MM-DD-Year', 'class':'form-control', 'required': 'required'}),

            'expiration_date': forms.DateInput(attrs={
                'placeholder': 'MM-DD-Year', 'class':'form-control', 'required': 'required'}),
    
        }
