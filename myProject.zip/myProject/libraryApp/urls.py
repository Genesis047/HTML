from django.urls import path
from libraryApp import views

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
	path('', views.home, name='home'),
	path('books/', views.books, name='books'),
	path('manage/', views.manage, name='manage'),
	path('issue/', views.issue, name='issue'),
	path('return/', views.returns, name='return'),
	path('requests/', views.requests, name='request'),

	path('add_book', views.add_book),
	path('delete/<person_pk>', views.delete, name='delete-person'),
	path('add_request/<person_id>', views.add_request),
	path('reject/<rejection>', views.reject),

	path('issue_book/<person_id>', views.issue_book),
	
	path('editing/<id>', views.editing),
	path('updating/<id>', views.updating),


] 
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
